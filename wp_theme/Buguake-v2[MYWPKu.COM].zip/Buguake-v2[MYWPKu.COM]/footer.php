﻿

<div id="footer" >
	
	<!--f2 begin-->
	<div class=" f2  ">
		
		<div class="f2-center">
			
			<div class="f2_1">
			
			</div>
			<div class="f2_2"></div>
			<div class="f2_3"></div>
			
		</div>
	</div>
	<!--f2 end-->
	
	<!--f3 begin-->
	<div class="f3 ">
		<div class="flinks col-md-8">
			<?php get_links_list(); ?> 
		</div>
	</div>
	<!--f3 end-->
	<!--f4 begin-->
	<div class="f4  ">
		<div class="f4-center">	
			<p >
				©2013 <?php bloginfo(’url’); ?> | Theme by <a href="http://www.cnsecer.com" target="_blank">安全者</a> | 
				Powered By <a href="http://cn.wordpress.org/">wordpress</a>&nbsp;and&nbsp;<a href="http://getbootstrap.com/">BootStrap</a> | 
				<?php echo stripslashes(get_option('cnsecer_icp')); ?> | <?php echo stripslashes(get_option('cnsecer_tongji')); ?> 	
			</p>		
		</div>
	</div>
	<!--f4 end-->
	<div style=" width:940px; margin:auto;"><?php echo get_option('mytheme_analytics'); ?></div>
	
</div>
<!--footer end-->

</div>



<?php echo stripslashes(get_option('cnsecer_share')); ?>



</body>

</html>
