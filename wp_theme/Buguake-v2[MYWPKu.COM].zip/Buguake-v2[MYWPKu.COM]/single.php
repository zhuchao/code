<?php
	/*  功能:
	*	判断是否为分类目录别名，如果不是，则使用single-all.php  文章模板
	*   如果是，则使用对应的文章模板  
	*/
if ( in_category('team') ) {
include(TEMPLATEPATH . '/single-article.php');
}
// elseif 在一次判断 想在加判断复制代码
elseif ( in_category('pic4') ) { // plugin 为category的别名
include(TEMPLATEPATH . '/single-video.php');
}


// elseif 结束
else {
include(TEMPLATEPATH . '/single-all.php');
}
?>