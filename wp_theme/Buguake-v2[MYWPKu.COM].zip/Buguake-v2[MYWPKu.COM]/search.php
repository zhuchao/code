<?php get_header(); ?>


<!--分类头部介绍开始-->
<div class="bs-header hidden-sm hidden-xs" id="content">
	<div class="container">
        <h1>搜索</h1>
        <p>为你搜到了如下结果,哥搜的准不准？^_^</p>
        
	</div>
</div>
<!--分类头部介绍结束-->
<div class="category">
	<div class="nav-bar hidden-sm  hidden-xs"></div>
	
	
	<div class="cate-main">
		<div class="cate-main-left" style="width:900px">
			<div class="j1"><a href="<?php bloginfo('url'); ?>" target="_top">首页</a> > 
				<?php if (get_option('all')!=""): ?>                                  <!--判断语句-->
				<?php echo get_option('all'); ?>                                 <!--输出语句-->                                                               <!--否定语句-->
				<?php endif; ?>

				<?php echo '>';wp_title(''); ?>
			</div>
			<div class="j3" style="width:900px">
				<?php $posts = query_posts($query_string . '&orderby=date&showposts=10'); ?>
				<?php if( $posts ) : ?>                                        
				<ul>
					<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>     
					<div class="cate-article" style="width:890px">
						<div class="row">
							<div class=" col-md-2 " >
								<a href="<?php the_permalink(); ?>"><img class="featurette-image img-responsive img-rounded" src="<?php post_thumbnail_src(); ?>" style="width: 110px; height: 75px;"></a>
							</div>
							<div class="col-md-10" >
								
								<div class="m1" style="width:750px">
									<div class="m2" style="width:720px">
										<a href="<?php the_permalink() ?>" target="_blank">
										<?php echo mb_strimwidth(get_the_title(), 0, 60,"...") ?>
										</a>
									</div>
									
									<div class="m4" style="width:720px">
										<a href="<?php the_permalink() ?>" target="_blank">
										<?php echo mb_strimwidth(strip_tags($post->post_content), 0,150,"..."); ?>
										</a>
									</div>
								</div>
								
							</div>  
						</div>
					</div>
					<?php endforeach; ?>                                          
					
					
				</ul>
				<?php endif; ?> 
				
				<div class="navigation"><?php pagination($query_string);  ?></div>
			</div>
		</div>

		<div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
	</div>
	
</div>

<!--ads begin-->
	<?php echo stripslashes(get_option('cnsecer_search-ads-right')); ?>
<!--ads end-->

<!--ads begin-->
	<?php echo stripslashes(get_option('cnsecer_search-ads-left')); ?>
<!--ads end-->

<?php get_footer(); ?>
