<?php get_header(); ?>

<!--slider begin-->      

<!-- 首页幻灯开始-->

<div class="banner has-dots hidden-sm hidden-xs" >
	<ul >
        <li style="background-image: url(' <?php bloginfo('template_directory');echo '/'.stripslashes(get_option('cnsecer_slider1')); ?>'); ">
			<div class="inner">
				<h1>新功能</h1>
				<p>搜索功能越来越牛逼了！要不你试试？</p>
				
				<a class="btn" href="javascript:alert('我擦！要不你搜索下?')">View More</a>
			</div>
		</li>
		
        <li style="background-image: url(' <?php bloginfo('template_directory');echo '/'.stripslashes(get_option('cnsecer_slider2')); ?>'); ">
			<div class="inner">
				<h1>新主题</h1>
				<p>本主题采用BootStrap构建,响应式布局。幻灯支持键盘导航,试试你的方向键吧。</p>
				
				<a class="btn" href="javascript:alert('下载个毛啊！没看哥还没做完呢。。。')">DOWNLOAD</a>
			</div>
		</li>
		
        <li style="background-image: url(' <?php bloginfo('template_directory');echo '/'.stripslashes(get_option('cnsecer_slider3')); ?>'); ">
			<div class="inner">
				<h1>开源</h1>
				<p>本站主题全部开源,现用主题暂时没有开发完成,上几个主题已经免费发布到本博客</p>
				
				<a class="btn" href="http://www.cnsecer.com/jianzhan/wordpress/">下载</a>
			</div>
		</li>
		
        <li style="background-image: url(' <?php bloginfo('template_directory');echo '/'.stripslashes(get_option('cnsecer_slider4')); ?>'); ">
			<div class="inner">
				<h1>关于</h1>
				<p>我是一个PHP业余爱好者,现在在郑州上大三。</p>
				
				<a class="btn" href="http://www.cnsecer.com/me/">更多</a>
			</div>
		</li>
	</ul>
	<ol class="dots"><li class="dot">1</li><li class="dot">2</li><li class="dot active">3</li><li class="dot">4</li></ol>
	
</div>
<div class="nav-bar hidden-sm hidden-xs"> </div>
<!-- 首页幻灯结束-->

<!--slider end-->


<div class="container " style="margin-top:30px;"> 
	
	<div class="m row">
		<div class="col-md-12">
			<div class="e1">
				<li class="z4">LATEAT ARTICLE</li>
				<li class="t1"><img src="<?php bloginfo('template_url'); ?>/images/sy1_18.jpg" /></li>
				<li class="z5">最新文章</li>
			</div>

			
		</div>
	</div>
	<div class="m1 row">
		<div class="b3">
			
			<div class="c1 col-md-4 ">
				<?php
					$slug = stripslashes(get_option('cnsecer_lal'));
					$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
					$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
				?>
				<?php $posts = get_posts( "category=($cat->term_id)&numberposts=1" ); ?>      
				<?php if( $posts ) : ?>  
				<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>  
				<div class="c2">
					<div class="c3">
					  <a href="<?php the_permalink() ?>" target="_blank"><?php echo mb_strimwidth(get_the_title(), 0, 40,"...") ?></a>
					 </div>
					
				</div>
				<div class="c5">
  					<a href="<?php the_permalink(); ?>"><img class="featurette-image img-responsive img-rounded" src="<?php post_thumbnail_src(); ?>" style="width: 260px; "></a>
				</div>
				<div class="c6">
                                  
					<ul>  
						<li>
							<p class="c8"><?php echo mb_strimwidth(strip_tags($post->post_content), 0,110,"..."); ?></p>
							<p class="c9"><a href="<?php the_permalink() ?>" target="_blank">——View details</a></p> 
						</li>                                         
					</ul>
					<?php endforeach; ?>  
					<?php endif; ?> 
				</div>
			</div>
			<div class="c10 col-md-4">
				<div class="c11">
					<?php
						$slug = stripslashes(get_option('cnsecer_lac'));
						$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
						$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
					?>
					
				</div>
				
				<?php $posts = get_posts( "category=($cat->term_id&numberposts=5" ); ?>     
				<?php if( $posts ) : ?>                                     
				<ul>
					<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>     
					<div class="c12"><li><a href="<?php the_permalink() ?>"target="_blank">
						<?php echo mb_strimwidth(get_the_title(), 0, 38,"...") ?><br />
						Time:<?php the_time('20y-m-d')?>
					</a></li></div>
					<?php endforeach; ?>                                          
				</ul>
				<?php endif; ?> 
				<div class="c13">01<br />02<br />03<br />04<br />05</div>
				
			</div>  
				<div class="b4 col-md-4">
				<?php
					$slug = stripslashes(get_option('cnsecer_lar'));
					$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
					$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
				?>
				<?php $posts = get_posts( "category=($cat->term_id)&numberposts=1" ); ?>      
				<?php if( $posts ) : ?>  
				<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>  
				<div class="c2">
					<div class="c3">
					  <a href="<?php the_permalink() ?>" target="_blank"><?php echo mb_strimwidth(get_the_title(), 0, 40,"...") ?></a>
					 </div>
					
				</div>
				<div class="c5">
  					<a href="<?php the_permalink(); ?>"><img class="featurette-image img-responsive img-rounded" src="<?php post_thumbnail_src(); ?>" style="width: 260px; "></a>
				</div>
				<div class="c6">
                                  
					<ul>  
						<li>
							<p class="c8"><?php echo mb_strimwidth(strip_tags($post->post_content), 0,110,"..."); ?></p>
							<p class="c9"><a href="<?php the_permalink() ?>" target="_blank">——View details</a></p> 
						</li>                                         
					</ul>
					<?php endforeach; ?>  
					<?php endif; ?> 
				</div>
		</div>
			
		</div>

	</div>
	
	<div class="m row">
		<div class="col-md-12">
			<div class="e1">
				<li class="z4">WORDPRESS THEMES</li>
				<li class="t1"><img src="<?php bloginfo('template_url'); ?>/images/sy1_18.jpg" /></li>
				<li class="z5">WP主题</li>
			</div>
			<div class="e2">
				<?php
						$slug = stripslashes(get_option('cnsecer_product'));
						$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
						$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
				?>
				<a href="<?php echo $cat_links; ?>" target="_blank"><img border="0" src="<?php bloginfo('template_url'); ?>/images/sy1_19.jpg" /></a>
			</div>
			
		</div>
	</div>
	<div class="m2 row">
		<div class="col-md-12">
			<div class="e3">
				<?php
						$slug = stripslashes(get_option('cnsecer_product'));
						$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
						$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
				?> 
				<div class="e4">                   
					<?php $posts = get_posts( "category=($cat->term_id&numberposts=5" ); ?>      
					<?php if( $posts ) : ?>                                      
					<ul>
						<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>     
						<li>
							<a href="<?php the_permalink() ?>" target="_blank"> <img src ="<?php post_thumbnail_src();?>"></a>
							<div class="e5"><a href="<?php the_permalink() ?>" target="_blank"><?php echo mb_strimwidth(get_the_title(), 0, 23,"...") ?></a></div>
							<div class="e6">Click to view</div>
							<div class="e7">Time:<?php the_time('20y-m-d')?></div>
						</li>
						<?php endforeach; ?>                                          
					</ul>
					<?php endif; ?> 
				</div>
			</div>
		</div>
	</div>
	
	<div class="m row">
		<div class="col-md-12">
			<div class="e1">
				<li class="z4">RANDOM ARTICLE</li>
				<li class="t1"><img src="<?php bloginfo('template_url'); ?>/images/sy1_18.jpg" /></li>
				<li class="z5">随机文章</li>
			</div>

		</div>
	</div>
	
	<div class="m3 row ">
		<div class="col-md-4 m3-col">
			<div class="c10">
				<div class="c11">
					<?php
						$slug = stripslashes(get_option('cnsecer_ral'));
						$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
						$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
					?>
					<a href="<?php echo $cat_links; ?>" target="_blank"><button class="btn btn-success">More info</button></a>
				</div>
				
				<?php $posts = get_posts( "category=($cat->term_id&numberposts=6" ); ?>     
				<?php if( $posts ) : ?>                                       
				<ul>
					<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>      
					<div class="c12"><li><a href="<?php the_permalink() ?>"target="_blank">
						<?php echo mb_strimwidth(get_the_title(), 0, 38,"...") ?><br />
						Time:<?php the_time('20y-m-d')?>
					</a></li></div>
					<?php endforeach; ?>                                         
				</ul>
				<?php endif; ?> 
				<div class="c13">01<br />02<br />03<br />04<br />05<br />06</div>
			</div>
		</div>
		<div class="col-md-4 m3-col">
			<div class="c10">
				<div class="c11">
					<?php
						$slug = stripslashes(get_option('cnsecer_rac'));
						$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
						$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
					?>
					<a href="<?php echo $cat_links; ?>" target="_blank"><button class="btn btn-success">More info</button></a>
				</div>
				
				<?php $posts = get_posts( "category=($cat->term_id&numberposts=6" ); ?>       
				<?php if( $posts ) : ?>                                       
				<ul>
					<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>    
					<div class="c12"><li><a href="<?php the_permalink() ?>"target="_blank">
						<?php echo mb_strimwidth(get_the_title(), 0, 38,"...") ?><br />
						Time:<?php the_time('20y-m-d')?>
					</a></li></div>
					<?php endforeach; ?>                                           
				</ul>
				<?php endif; ?> 
				<div class="c13">01<br />02<br />03<br />04<br />05<br />06</div>
			</div>				
		</div>
		<div class="col-md-4 m3-col">
			<div class="c10">
				<div class="c11">
					<?php
						$slug = stripslashes(get_option('cnsecer_rar'));
						$cat=get_category_by_slug($slug); //获取分类别名为 wordpress 的分类数据
						$cat_links=get_category_link($cat->term_id); // 通过$cat数组里面的分类id获取分类链接
					?>
					<a href="<?php echo $cat_links; ?>" target="_blank"><button class="btn btn-success">More info</button></a>
				</div>
				
				<?php $posts = get_posts( "category=($cat->term_id&numberposts=6" ); ?>       
				<?php if( $posts ) : ?>                                       
				<ul>
					<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>      
					<div class="c12"><li><a href="<?php the_permalink() ?>"target="_blank">
						<?php echo mb_strimwidth(get_the_title(), 0, 38,"...") ?><br />
						Time:<?php the_time('20y-m-d')?>
					</a></li></div>
					<?php endforeach; ?>                                      
				</ul>
				<?php endif; ?> 
				<div class="c13">01<br />02<br />03<br />04<br />05<br />06</div>
			</div>				
		</div>
		
		
	</div>
	
	
</div>

</div>
<?php get_footer(); ?>


<script>
	if(window.chrome) {
		$('.banner li').css('background-size', '100% 100%');
	}
	
	$('.banner').unslider({
		arrows: true,
		fluid: true,
		dots: true
	});
	
	//  Find any element starting with a # in the URL
	//  And listen to any click events it fires
	$('a[href^="#"]').click(function() {
		//  Find the target element
		var target = $($(this).attr('href'));
		
		//  And get its position
		var pos = target.offset(); // fallback to scrolling to top || {left: 0, top: 0};
		
		//  jQuery will return false if there's no element
		//  and your code will throw errors if it tries to do .offset().left;
		if(pos) {
			//  Scroll the page
			$('html, body').animate({
				scrollTop: pos.top,
				scrollLeft: pos.left
			}, 1000);
		}
		
		//  Don't let them visit the url, we'll scroll you there
		return false;
	});
	
	
	</script>											