<?php get_header(); ?>


<!--分类头部介绍开始-->
<div class="bs-header hidden-sm hidden-xs" id="content">
	<div class="container">
        <h1>Welcome</h1>
        <p>这是我博客的新主题,看着还可以吧。</p>
        
	</div>
</div>
<!--分类头部介绍结束-->
<div class="category">
	<div class="nav-bar hidden-sm  hidden-xs"></div>
	
	
	<div class="cate-main">
		<div class="cate-main-left">
			<div class="j1"><a href="<?php bloginfo('url'); ?>" target="_top">首页</a> > 
				<?php if (get_option('all')!=""): ?>                                  <!--判断语句-->
				<?php echo get_option('all'); ?>                                 <!--输出语句-->
				<?php else : ?>                                                                 <!--否定语句-->
				
				<?php endif; ?>
			<?php wp_title(''); ?></div>
			<div class="j3">
				<?php $posts = query_posts($query_string . '&orderby=date&showposts=10'); ?>
				<?php if( $posts ) : ?>                                        
				<ul>
					<?php foreach( $posts as $post ) : setup_postdata( $post ); ?>     
					<div class="cate-article">
						<div class="row">
							<div class=" col-md-2 " >
								<a href="<?php the_permalink(); ?>"><img class="featurette-image img-responsive img-rounded" src="<?php post_thumbnail_src(); ?>" style="width: 75px; height: 75px;"></a>
							</div>
							<div class="col-md-10" >
								
								<div class="m1">
									<div class="m2">
										<a href="<?php the_permalink() ?>" target="_blank">
										<?php echo mb_strimwidth(get_the_title(), 0, 60,"...") ?>
										</a>
									</div>
									
									<div class="m4">
										<a href="<?php the_permalink() ?>" target="_blank">
										<?php echo mb_strimwidth(strip_tags($post->post_content), 0,150,"..."); ?>
										</a>
									</div>
								</div>
								
							</div>  
						</div>
					</div>
					<?php endforeach; ?>                                          
					
					
				</ul>
				<?php endif; ?> 
				
				<div class="navigation"><?php pagination($query_string);  ?></div>
			</div>
		</div>
		<!--sidebar begin-->
		<?php get_sidebar(); ?>
		<!--sidebar end-->
		
		<div style="font: 0px/0px sans-serif;clear: both;display: block"> </div>
	</div>
	
</div>



<?php get_footer(); ?>
