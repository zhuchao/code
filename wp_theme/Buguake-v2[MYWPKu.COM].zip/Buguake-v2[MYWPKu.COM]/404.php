<?php get_header(); ?>
<div class="container">
	<div class="error404">
	<h2>Error 404 - Page Not Found</h2>
	</div>

</div>

<?php //get_sidebar(); ?>

<?php get_footer(); ?>

<style type="text/css" media="screen">
.error404{
	height: 500px;
	background-color: #ccc;
	margin-top: 40px;
}
.error404 h2{
	text-align: center;

}
	
</style>>