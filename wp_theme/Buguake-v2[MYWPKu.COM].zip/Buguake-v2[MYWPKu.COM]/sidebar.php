<div class="cate-main-right">
    <div class="k1">  <p>最新文章</p>  </div> 
        <div class="k3">
            <ul>
                <?php $post_query = new WP_Query('showposts=8'); while ($post_query->have_posts()) : $post_query->the_post(); $do_not_duplicate = $post->ID; ?>
                <li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
                <?php endwhile;?>
            </ul>
        </div>

     <div class="k1">  <p>精彩推荐</p>  </div>
        <!-- <div class="tagcloud"><?php //wp_tag_cloud();?></div> -->
         <div class="cate250">
             <?php echo stripslashes(get_option('cnsecer_cate-ads-sidebar')); ?>
         </div>
    
     <div class="k1">  <p>热门文章</p>  </div>   
        <div class="k3">
            <?php cnsecer_get_most_viewed();  ?> 
        </div>



</div>
