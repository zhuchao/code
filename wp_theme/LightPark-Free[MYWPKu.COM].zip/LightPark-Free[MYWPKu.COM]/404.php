<?php get_header(); ?>

	<h2>Error 404 - Page Not Found</h2>

<?php get_sidebar(); ?>

<?php get_footer(); ?>