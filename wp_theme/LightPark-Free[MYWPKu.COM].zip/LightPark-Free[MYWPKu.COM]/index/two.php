<div id="two_index">
    <div class="left_man"><?php get_template_part( 'index/left_news' ); ?></div>
    <div class="right_man"><?php get_template_part( 'index/right_news' ); ?></div>


</div>
