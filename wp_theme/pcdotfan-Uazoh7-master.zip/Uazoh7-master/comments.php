<?php get_header(); paginate_comments_links();?>
<?php wp_list_comments( $args ); ?>
<?php wp_footer(); ?></body> </html>