	  <section class="uazoh7-section uazoh7-home-slider">
        <div id="layerslider" class="uazoh7-layerslider" style="height: 500px;">
            <?php if(isset($smof_data['silder_num_1']) && ($smof_data['silder_num_1'] != 0)) { ?>
            <div class="ls-layer" style="transition3d: all; transition2d: all;">
              <img class="ls-bg" src="<?php echo $smof_data['silder_num_1_img']['url']; ?>" alt="<?php echo $smof_data['silder_num_1_block_h3']; ?>|<?php echo $smof_data['silder_num_1_block_h2']; ?>">
              <div class="uazoh7-layerslider-block ls-s1" style="<?php echo 'top:'.$smof_data['silder_num_1_block_top'].'px; left: '.$smof_data['silder_num_1_block_left'].'px; '.$smof_data['silder_style_text'] ;?>">
                <h3><?php echo $smof_data['silder_num_1_block_h3']; ?></h3>
                <h2><?php echo $smof_data['silder_num_1_block_h2']; ?></h2>
                <p><?php echo $smof_data['silder_num_1_block_p']; ?></p>
              </div>
            </div><?php }?>
            <?php if(isset($smof_data['silder_num_2']) && ($smof_data['silder_num_2'] != 0)) { ?>
            <div class="ls-layer" style="transition3d: all; transition2d: all;">
              <img class="ls-bg" src="<?php echo $smof_data['silder_num_2_img']['url']; ?>" alt="<?php echo $smof_data['silder_num_2_block_h3']; ?>|<?php echo $smof_data['silder_num_2_block_h2']; ?>">
              <div class="uazoh7-layerslider-block ls-s1" style="<?php echo 'top:'.$smof_data['silder_num_1_block_top'].'px; left: '.$smof_data['silder_num_1_block_left'].'px; '.$smof_data['silder_style_text'] ;?>">
                <h3><?php echo $smof_data['silder_num_2_block_h3']; ?></h3>
                <h2><?php echo $smof_data['silder_num_2_block_h2']; ?></h2>
                <p><?php echo $smof_data['silder_num_2_block_p']; ?></p>
              </div>
            </div><?php }?>
            <?php if(isset($smof_data['silder_num_3']) && ($smof_data['silder_num_3'] != 0)) { ?>
            <div class="ls-layer" style="transition3d: all; transition2d: all;">
              <img class="ls-bg" src="<?php echo $smof_data['silder_num_3_img']['url']; ?>" alt="<?php echo $smof_data['silder_num_3_block_h3']; ?>|<?php echo $smof_data['silder_num_3_block_h2']; ?>">
              <div class="uazoh7-layerslider-block ls-s1" style="<?php echo 'top:'.$smof_data['silder_num_1_block_top'].'px; left: '.$smof_data['silder_num_1_block_left'].'px; '.$smof_data['silder_style_text'] ;?>">
                <h3><?php echo $smof_data['silder_num_3_block_h3']; ?></h3>
                <h2><?php echo $smof_data['silder_num_3_block_h2']; ?></h2>
                <p><?php echo $smof_data['silder_num_3_block_p']; ?></p>
              </div>
            </div><?php }?>
        </div>
      </section>